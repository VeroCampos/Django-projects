from django.apps import AppConfig


class TvshowsValAppConfig(AppConfig):
    name = 'tvshows_val_app'
